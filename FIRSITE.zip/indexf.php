<html>
<head>
<title>Online FIR</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="/FIRSITE/include/admin.css" rel="stylesheet" type="text/css">
<link href="/FIRSITE/include/menu.css" rel="stylesheet" type="text/css">
<link href="/FIRSITE/include/main.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/javascript" src="/FIRSITE/library/commonf.js"></script>
<script language="JavaScript" type="text/javascript" src="/FIRSITE/library/complainsf.js"></script>
</head>
<body>
<br/><br/>
<table width="900" border="0" align="center" cellpadding="0" cellspacing="1" class="graybox">
  <tr>
    <tdcolspan="2"><img src="/complain/images/fir.gif" width="900" height="120"></td>
  </tr>
  <tr>
    <td width="20%" valign="top" class="navArea"><p>&nbsp;</p>
 	<div id="ddblueblockmenu">
	  <div class="menutitle">Complainer View Menu</div>
		  <ul>
			<li><a href="/FIRSITE/">Welcome,&nbsp;<? echo ucwords($_SESSION['user_name']); ?></a></li>
			<li><a href="add_fir.php">Lodge FIR</a></li>
			<li><a href="track-status.php">View FIR</a></li>
			<li><a href="/FIRSITE/loginf.php">Logout</a></li>
		  </ul>
	  <div class="menutitle">&nbsp;</div>	  
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
	</td>
    <td width="720" valign="top" class="contentArea"><table width="100%" border="0" cellspacing="0" cellpadding="20">
        
         <h1><font style ="text-shadow: 4px 4px 4px #aaa;"><p align="center" style="color:#990000; font-size:30px;font-weight:bold;">OnlineFIR</p></font></h1></td></tr>
<tr>
<img src="complain.jpg"  style="float:left;border:0px; padding:0px; height="500" width="500"/></tr>
<tr><td>
<marquee><p align="left" style="line-height:30px; padding:00px;" color="green"><b>
Online FIR System</b> is a site for Mumbai,Maharashtra, India.
 Here you can Lodge your FIR against crime.
 </p></marquee>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
          </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
